﻿Use first_db
insert into Countries values
('India'),('USA')

select * from Countries;
select * from States
select * from Cities
insert into States values
('Up',1),('Bihar',1),('California',2),('Washington',2)

insert into Cities values
     ('MuradaBa',1),('Nalanda',2),('Los Angeles',3)



